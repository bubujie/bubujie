<?php
/**
 * 首页控制器
 *
 * @since 2009-7-9
 * @copyright http://www.114la.com
 */
!defined('PATH_ADMIN') && exit('Forbidden');

class ctl_index
{
	/**
	 * 默认
	 *
	 * @return viod
	 */
	public function index ()
	{
	}
}
?>