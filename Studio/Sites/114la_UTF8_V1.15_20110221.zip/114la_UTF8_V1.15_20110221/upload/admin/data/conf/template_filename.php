<?php
/**
 * 模块文件名
 *
 * @since 2009-7-14
 * @copyright http://www.114la.com
 */
!defined('PATH_ADMIN') && exit('Forbidden');

$template_filename = array(
    '网址提交' => 'url_submit.tpl',
    '意见反馈' => 'feedback.tpl',
);
?>