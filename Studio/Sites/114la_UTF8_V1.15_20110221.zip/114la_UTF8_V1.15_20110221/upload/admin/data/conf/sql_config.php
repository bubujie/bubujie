<?php
!defined('PATH_ADMIN') && exit('Forbidden');

$GLOBALS ['database'] ['db_user'] = 'root';
$GLOBALS ['database'] ['db_pass'] = '111111';
$GLOBALS ['database'] ['db_name'] = 'a11';
$GLOBALS ['database'] ['db_charset'] = 'utf8';
$GLOBALS ['database'] ['table_prefix'] = 'sdfas';
$GLOBALS ['database'] ['db_host'] ['master'] = 'localhost';
$GLOBALS ['database'] ['manager'] = 'fdsa';
$GLOBALS ['database'] ['managerpw'] = '0cc175b9c0f1b6a831c399e269772661';
$GLOBALS ['database'] ['staticfolder'] = '/html';
?>
