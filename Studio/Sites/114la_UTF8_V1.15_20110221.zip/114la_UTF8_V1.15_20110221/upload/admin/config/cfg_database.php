<?php
!defined('PATH_ADMIN') && exit('Forbidden');
$GLOBALS ['database'] ['db_user'] = '114la_v4';
$GLOBALS ['database'] ['db_pass'] = '114la_v4';
$GLOBALS ['database'] ['db_name'] = '114la_v4';
$GLOBALS ['database'] ['db_charset'] = 'utf8';
$GLOBALS ['database'] ['table_prefix'] = 'ylmf_';
$GLOBALS ['database'] ['db_host'] = '192.168.1.12';
$GLOBALS ['database'] ['manager'] = 'admin';
$GLOBALS ['database'] ['managerpw'] = 'e10adc3949ba59abbe56e057f20f883e';
$GLOBALS ['database'] ['staticfolder'] = '/html';
?>