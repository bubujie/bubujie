<?php
$lang=array(
    '777_test'              =>"<font color='red'> 777属性检测不通过</font>",
    'no_file'               =>"<font class=c1>文件不存且无权限建立,请设置目录写权限或手动上传此文件</font>",
    'test_ok'               =>"<font color='#00CC00'> 可写<b>√</b></font>",
    'no_write'              =>"目录无法书写,请速将根目录属性设置为777",
    'no_database'           =>"指定的数据库不存在,且您无权限建立,请联系服务器管理员!",
    'low_version'           =>"很抱歉，您的php版本太低，请升级至5.0以上版本。",
    'del_install'           =>"请记住用FTP删除 install.php 安装文件!",
    'creat_table'           =>"建立数据表",
    'success'               =>"完成",
);
?>
